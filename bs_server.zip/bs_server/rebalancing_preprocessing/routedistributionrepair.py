# -*- coding:utf-8 _*-
""" 
@author:Runqiu Hu
@license: Apache Licence 
@file: routedistributionrepair.py
@time: 2020/10/10
@contact: hurunqiu@live.com
@project: bikeshare rebalancing

* Cooperating with Dr. Matt in 2020
"""

from itertools import groupby

import numpy as np
from pymoo.model.repair import Repair

from bs_server.confreader import read_config as cfg
from bs_server.data import station_info
from bs_server.result_evaluation.evaluate import evaluate

station_count = int(cfg('station_info', 'station_count'))
truck_count = int(cfg('station_info', 'truck_count'))
consider_priority = bool(cfg('meta_info', 'priority_considered'))


class RouteDistributionRepair(Repair):
    def __init__(self, ref_dir):
        self.ref_dir = ref_dir

    def _do(self, problem, pop, **kwargs):
        sub_idx = kwargs['subproblem_index']
        # the routing information population (each row one individual)
        population = pop.get("X")
        # print(population.shape)
        # the packing plan for i
        z = population
        # zres = []
        # for zidx, z in enumerate(zp):
        # find all the trucks in the population, insert them as averagely as possible
        stations = z[z < station_count]
        split = np.array_split(stations, truck_count)
        result = []
        for idx, chunk in enumerate(split):
            if idx != len(split) - 1:
                chunk = np.append(chunk, station_count + idx)
            result = result + list(chunk)
        z = np.asarray(result)
        # print(self.ref_dir[zidx, 1] > self.ref_dir[zidx, 0])
        # if self.ref_dir[zidx, 1] > self.ref_dir[zidx, 0]:


        z = np.asarray(self.priority_repair(z))
        # zres.append(z)
        # print(z)
        # set the design variables for the population
        pop.set("X", z)
        return pop

    def priority_repair(self, solution):
        new_solution = None
        counter = 0
        while counter < 3 and self.is_dominated_by(new_solution, solution):
            counter += 1
            routes = [list(group) for k, group in groupby(solution, lambda y: y >= station_count) if not k]
            new_solution = []
            for idx, route in enumerate(routes):
                selected = self.roulette_wheel(route)
                # print(selected)
                selected = selected['origin_index']
                tmp = np.delete(route, np.where(route == selected))
                new_sol = [selected] + list(tmp)
                new_solution += list(new_sol) + [station_count + idx]
                # print("origin:" + str(route))
                # print("new:   " + str(new_sol))
        if new_solution is None or self.is_dominated_by(new_solution, solution):
            return solution
        else:
            return new_solution[:-1]

    @staticmethod
    def roulette_wheel(solution):
        population = []
        station_list = list(station_info.keys())
        for station in solution:
            population.append({
                'origin_index': station,
                'station_id': station_list[station],
                'priority': station_info[station_list[station]]['priority']
            })
        maximum = sum([c['priority'] for c in population])
        selection_probs = [c['priority'] / maximum for c in population]
        k = population[np.random.choice(len(population), p=selection_probs)]
        # print(k['station_id'])
        return k

    @staticmethod
    def is_dominated_by(new_sol, solution):
        if new_sol is None or solution is None:
            return True
        new_sol_map = []
        old_sol_map = []
        for station in new_sol:
            new_sol_map.append(list(station_info.keys())[station] if station < station_count else -1)
        for station in solution:
            old_sol_map.append(list(station_info.keys())[station] if station < station_count else -1)
        eval_new = evaluate(new_sol_map)
        eval_old = evaluate(old_sol_map)
        return eval_new[2] <= eval_old[2]
