# -*- coding:utf-8 _*-
""" 
@author:Runqiu Hu
@license: Apache Licence 
@file: moead_run.py
@time: 2020/10/07
@contact: hurunqiu@live.com
@project: bikeshare rebalancing

* Cooperating with Dr. Matt in 2020
"""
from flask import Flask, request
from flask.json import jsonify
from flask_cors import *

from bs_server.rebalancing_preprocessing.CustomJSONEncoder import CustomJSONEncoder
from bs_server.rebalancing_preprocessing.demand_calculation import *
from bs_server.rebalancing_preprocessing.station_info import StationInfo
from bs_server.rebalancing_preprocessing.topsis import priority_calculation
from bs_server.confreader import read_config as cfg

app = Flask(__name__)
cors = CORS(app)
app.config['CORS_HEADERS'] = 'Content-Type'
app.json_encoder = CustomJSONEncoder
station_count = int(cfg('station_info', 'station_count'))

def initialize_station_information():
    past_rent = np.array(
        [1, 2, 4, 9, 3, 0, 4, 0, 8, 5, 3, 2, 10, 0, 1, 6, 1,
         4, 0, 0, 0, 5, 2, 1, 8, 4, 0, 0, 0, 2, 0, 0, 2, 5,
         3, 2, 6, 1, 2, 0, 4, 0, 1, 1, 2, 8, 1, 6, 4, 0, 0,
         3, 1, 2, 8, 0, 1, 4, 1, 1, 3, 7, 2, 4, 2, 1, 1, 0,
         2, 0, 4, 1, 7, 4, 0, 1, 1, 3, 0, 0, 4, 2, 2, 6, 3,
         17, 1, 1, 9, 5, 12, 0, 1, 1, 7, 2, 5, 0, 5, 0, 7, 4,
         2, 3, 4, 3, 0, 1, 4, 5, 0, 3, 2, 1, 1, 19, 7, 11, 0,
         3, 6, 3, 1, 8, 3, 0, 3, 8, 1, 6, 8, 1, 4, 8, 6, 0,
         0, 3, 3, 3, 3, 3, 11, 2, 2, 1, 1, 3, 3, 1, 0, 5, 8,
         1, 2, 8, 5, 6, 1, 0, 0, 0, 4, 1])
    past_return = np.array(
        [0, 22, 0, 2, 8, 1, 13, 1, 2, 1, 3, 1, 4, 2, 2, 2, 2,
         2, 3, 1, 0, 1, 1, 1, 2, 3, 2, 1, 2, 0, 3, 0, 0, 1,
         10, 3, 5, 1, 5, 3, 3, 0, 0, 1, 2, 2, 11, 4, 2, 0, 3,
         2, 6, 4, 5, 2, 1, 1, 1, 2, 1, 6, 0, 2, 4, 0, 1, 0,
         2, 0, 6, 2, 6, 0, 0, 1, 0, 5, 5, 4, 2, 2, 6, 4, 0,
         6, 2, 1, 0, 1, 3, 4, 2, 1, 3, 2, 1, 1, 3, 0, 5, 7,
         4, 0, 5, 2, 0, 1, 6, 1, 0, 4, 2, 5, 6, 4, 5, 3, 5,
         7, 6, 1, 3, 13, 1, 0, 3, 2, 2, 5, 2, 3, 2, 15, 7, 0,
         1, 6, 1, 4, 1, 1, 5, 1, 1, 0, 0, 13, 1, 2, 1, 2, 2,
         3, 2, 1, 4, 2, 0, 0, 1, 0, 1, 2])
    pred_rent = np.array(
        [3, 15, 14, 10, 10, 6, 30, 10, 17, 13, 14, 11, 29, 3, 15, 20, 3,
         10, 3, 5, 2, 4, 8, 7, 11, 15, 2, 8, 1, 17, 20, 6, 0, 11,
         12, 10, 22, 15, 19, 11, 6, 0, 8, 1, 11, 16, 10, 9, 21, 6, 12,
         35, 5, 11, 30, 2, 1, 2, 3, 13, 9, 15, 8, 8, 14, 1, 3, 4,
         6, 7, 13, 4, 20, 17, 5, 4, 13, 22, 5, 13, 31, 7, 11, 10, 6,
         58, 4, 11, 34, 12, 48, 21, 2, 7, 29, 10, 9, 7, 35, 1, 17, 16,
         10, 17, 16, 15, 10, 4, 17, 7, 3, 19, 7, 7, 37, 54, 9, 21, 8,
         30, 58, 16, 9, 28, 14, 5, 11, 26, 5, 28, 13, 17, 17, 59, 23, 6,
         12, 13, 10, 3, 3, 13, 39, 5, 5, 4, 4, 13, 3, 7, 13, 6, 26,
         2, 9, 18, 15, 11, 1, 0, 4, 7, 9, 11])
    pred_return = np.array(
        [1, 28, 23, 14, 41, 14, 14, 0, 6, 9, 29, 11, 4, 4, 7, 11, 6,
         10, 16, 1, 4, 6, 9, 8, 14, 6, 0, 8, 1, 13, 24, 12, 0, 20,
         12, 16, 22, 9, 9, 14, 13, 0, 11, 4, 3, 38, 38, 26, 16, 5, 12,
         3, 12, 11, 18, 13, 4, 2, 1, 6, 22, 64, 16, 7, 6, 0, 1, 2,
         7, 6, 45, 14, 9, 6, 1, 3, 15, 22, 19, 14, 20, 9, 6, 8, 2,
         25, 2, 18, 4, 3, 29, 20, 18, 6, 19, 10, 14, 11, 14, 29, 15, 16,
         17, 35, 28, 11, 8, 4, 54, 9, 4, 14, 11, 8, 12, 19, 13, 14, 12,
         22, 31, 19, 8, 58, 9, 8, 29, 44, 14, 6, 8, 11, 11, 57, 11, 12,
         13, 19, 3, 4, 2, 14, 14, 17, 15, 2, 2, 18, 9, 12, 7, 3, 11,
         0, 2, 15, 37, 15, 7, 0, 2, 2, 2, 7])
    velocity = calculate_rent_return_velocity(
        past_rent=past_rent,
        past_return=past_return,
        pred_rent=pred_rent,
        pred_return=pred_return
    )
    station_dict = {}
    counter = 0
    net_demand = 0
    for i in range(len(pred_return)):
        station = StationInfo(i)
        calculate_full_empty_time(station, velocity, 60)
        calculate_warning_time(station, velocity, 60)
        calculate_demand(station, 60, velocity)
        if station.demand != 0:
            counter += 1
            net_demand += station.demand
        station.ratio = round(initial_bike[i] / max_capacity[i], 2)
        station.latest_time = station.full_empty_time + 5
        station_dict[i] = station.__dict__
        station.velocity = round(velocity[i], 2)
    # print(counter, net_demand)
    print(station_dict)
    return station_dict


# 分区接口
@app.route('/clustering', methods=['POST'])
@cross_origin()
def update_cluster():
    # station_dict = initialize_station_information()
    # station_for_cluster = pd.DataFrame.from_dict(station_dict).T[['station_id', 'demand']]
    # clustering(station_for_cluster)
    station_data = request.get_json()

    cluster_result = {0: 0, 1: 1, 2: 2, 3: 1, 4: 0, 5: 2, 6: 1, 9: 1, 10: 3, 11: 3, 12: 1, 13: 2, 14: 2, 15: 0, 16: 1,
                      17: 2, 18: 1, 19: 0, 20: 0, 21: 3, 22: 2, 23: 1, 24: 1, 26: 2, 28: 0, 30: 3, 32: 2, 33: 3, 34: 0,
                      35: 1, 36: 1, 37: 3, 38: 2, 39: 0, 40: 2, 43: 1, 44: 0, 45: 1, 46: 0, 47: 0, 48: 2, 51: 3, 52: 1,
                      55: 2, 56: 2, 57: 1, 59: 2, 61: 1, 62: 0, 63: 2, 64: 0, 65: 1, 66: 0, 67: 1, 68: 1, 69: 2, 70: 2,
                      72: 1, 73: 1, 75: 2, 76: 3, 79: 0, 80: 1, 81: 3, 82: 0, 83: 2, 84: 0, 87: 2, 88: 3, 89: 2, 90: 3,
                      92: 3, 94: 3, 95: 2, 97: 2, 98: 2, 99: 1, 100: 0, 101: 0, 105: 1, 106: 1, 107: 1, 109: 3, 110: 1,
                      113: 0, 114: 1, 115: 2, 116: 1, 117: 2, 118: 3, 119: 0, 120: 3, 122: 2, 123: 0, 124: 1, 125: 1,
                      126: 2, 128: 3, 130: 1, 131: 3, 132: 1, 133: 1, 134: 3, 135: 2, 136: 1, 137: 2, 138: 0, 139: 2,
                      141: 3, 142: 2, 143: 0, 144: 1, 146: 0, 147: 1, 148: 3, 149: 1, 150: 0, 152: 2, 153: 2, 154: 0,
                      155: 3, 156: 3, 157: 1, 158: 0, 159: 1, 160: 3, 161: 0, 162: 2, 163: 1, 164: 1, 165: 1, 166: 0,
                      167: 2, 168: 1, 169: 0, 170: 2, 171: 0, 172: 2, 173: 0, 174: 3, 175: 1, 176: 1, 177: 2, 178: 0,
                      179: 1, 180: 2, 181: 0, 182: 3, 183: 2, 184: 1, 185: 0, 186: 1, 187: 0, 188: 2, 189: 0, 190: 3,
                      191: 0, 192: 1, 194: 0, 195: 2, 196: 2, 197: 3, 198: 0, 199: 1, 200: 1, 201: 1, 202: 0, 203: 2,
                      204: 0, 205: 3, 206: 0, 207: 2, 209: 1, 210: 0, 211: 0, 213: 0, 214: 2, 215: 3, 217: 0, 218: 0,
                      219: 3, 220: 1, 221: 1, 222: 2, 223: 0, 224: 3, 225: 3, 226: 0, 227: 1, 228: 2, 230: 2, 231: 1,
                      232: 2, 233: 2, 234: 1, 235: 0, 237: 2, 238: 1, 239: 1, 240: 0, 241: 2, 242: 3, 244: 0, 245: 0,
                      247: 1, 248: 0, 249: 3, 250: 0, 253: 3, 254: 2, 256: 1, 257: 0, 258: 1, 259: 1, 261: 3, 262: 3,
                      263: 2, 264: 3, 265: 1, 266: 1, 267: 2, 268: 3, 269: 1, 271: 0, 272: 1, 274: 0, 275: 0, 276: 1,
                      277: 1, 278: 1, 279: 1, 280: 0, 281: 1, 282: 1, 283: 2, 284: 2, 285: 2, 286: 2, 288: 3, 289: 0,
                      290: 3, 291: 0, 292: 2, 293: 1, 294: 0, 295: 3, 296: 2, 298: 2}
    for station in station_data:
        if station['station_id'] in cluster_result.keys() and station['demand'] != 0:
            # station['cluster'] = cluster_result[station_info['station_id']] + 1
            station['cluster'] = 1
        else:
            station['cluster'] = "不参与调度"
    return jsonify(station_data)


# 重要度计算接口
@app.route('/priority', methods=['POST'])
@cross_origin()
def update_priority():
    station_data = request.get_json()
    selected_cluster = station_data[0]['cluster']
    calculate_distance(station_data, selected_cluster)
    topsis_indicator = pd.DataFrame(station_data)[['station_id', 'full_empty_time', 'demand', 'distance']]
    priority = priority_calculation(topsis_indicator)
    pri_dict = priority.set_index('ID').T.to_dict('dict')
    for station in station_data:
        station['priority'] = round(pri_dict[station['station_id']]['e'], 2)
    print(sorted(station_data, key = lambda i: i['priority'], reverse=True)[:station_count])
    return jsonify(station_data)


@app.route('/station_info', methods=['GET'])
@cross_origin()
def get_station_info():
    all_station_info = initialize_station_information()
    obj = jsonify(all_station_info)
    return obj


if __name__ == '__main__':
    app.config['JSON_AS_ASCII'] = False
    app.run(host="0.0.0.0", port=5000, debug=None)
