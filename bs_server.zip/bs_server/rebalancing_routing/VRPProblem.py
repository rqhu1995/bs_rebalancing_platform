# -*- coding:utf-8 _*-
""" 
@author:Runqiu Hu
@license: Apache Licence 
@file: VRPProblem.py 
@time: 2020/10/04
@contact: hurunqiu@live.com
@project: bikeshare rebalancing

* Cooperating with Dr. Matt in 2020

"""

from itertools import groupby

from geopy.distance import geodesic
from more_itertools import pairwise
from pymoo.model.problem import Problem

from bs_server.confreader import read_config as cfg
from bs_server.data import *

station_count = int(cfg('station_info', 'station_count'))
truck_count = int(cfg('station_info', 'truck_count'))


# objective_count = cfg('station_info', 'obj_coutn')

class BSRebalancing(Problem):

    def __init__(self, **kwargs):
        super().__init__(n_var=station_count + truck_count - 1, n_obj=2, n_constr=0, type_var=np.int, **kwargs)
        self.xl = np.zeros(self.n_var)
        self.xu = np.array([[self.n_var - 1] * self.n_var])

    # 三个目标：满意度折算成本、调度量目标偏离惩罚、调度成本
    def _evaluate(self, x, out, *args, **kwargs):
        station_list = list(final_station_info.keys())
        result = None
        single_route = x.copy()
        for row in range(x.shape[0]):
            for col in range(x.shape[1]):
                single_route[row, col] = station_list[x[row, col]] if x[row, col] < station_count else -1
        for cnt in range(x.shape[0]):
            real_route = list(single_route[cnt, :])
            routes = [list(group) for k, group in groupby(real_route, lambda y: y == -1) if not k]
            objective_1 = 0
            objective_2 = 0
            objective_3 = 0
            for route in routes:
                current_time = 0
                center_to_first = geodesic((lat_lon[route[0]][1], lat_lon[route[0]][0]), center).km / truck_velocity
                current_time += center_to_first
                objective_3 += center_to_first * travel_cost
                truck_inventory = 0
                for station, next_station in pairwise(route + [route[0]]):
                    func_2 = self.derivation_from_target_penalty_calculation(station, truck_inventory)
                    # objective_1 -= 80 * station_info[station]['priority'] * self.satisfaction_calculation(station,
                    #                                                                                       current_time,
                    #                                                                                       func_2[2])
                    objective_1 -= 1 * self.satisfaction_calculation(station, current_time, func_2[2])
                    objective_2 -= func_2[2]
                    truck_inventory = func_2[1]
                    travel_time_to_next = distance_matrix[station, next_station] / truck_velocity
                    working_time = func_2[2] * 1 / 6
                    objective_3 += travel_time_to_next * travel_cost + working_time * working_cost
                    current_time += distance_matrix[station, next_station] / truck_velocity + working_time
                    if current_time > 15:
                        break
            if result is None:
                result = np.array([[objective_1, objective_2, objective_3]])
            else:
                result = np.vstack((result, np.array([objective_1, objective_2, objective_3])))

        out["F"] = result

    @staticmethod
    def satisfaction_calculation(station, arriving_time, rebalancing_amount):
        expected_time = station_info[station]['full_empty_time']
        # 晚于最晚到达时间，满意度全部为0
        if arriving_time >= expected_time + reserved_time:
            return 0
        # 在下降期间到达：
        if expected_time < arriving_time < expected_time + reserved_time:
            # 降到0以前一共能调度的车辆数
            valid_amount = (expected_time + reserved_time - arriving_time) / 10 * 60
            total_sat = 0
            for i in range(1, int(min(valid_amount, rebalancing_amount)) + 1):
                total_sat += -1 / reserved_time * (arriving_time + 10 / 60 * i - expected_time - reserved_time)
            return total_sat
        # 在下降之前到达
        if arriving_time <= expected_time:
            # 开始下降前一共能调度的车辆数
            # print(arriving_time, expected_time)
            valid_amount_01 = (expected_time - arriving_time) / 10 * 60
            total_sat = min(valid_amount_01, rebalancing_amount) * 1
            valid_amount_02 = (expected_time + reserved_time - arriving_time) / 10 * 60
            if rebalancing_amount - valid_amount_01 > 0:
                for i in range(1, int(min(valid_amount_02, rebalancing_amount - valid_amount_01)) + 1):
                    total_sat += -1 / reserved_time * (10 / 60 * i - reserved_time)
            return total_sat

    @staticmethod
    def derivation_from_target_penalty_calculation(station, truck_inventory):
        station_demand = station_info[station]['demand']
        rebalancing_amount = 0
        cmax = station_info[station]['max_capacity']
        init_inventory = station_info[station]['init_inventory']
        if station_demand > 0:
            rebalancing_amount = min(min(truck_inventory, station_demand), cmax - init_inventory)
            truck_inventory -= rebalancing_amount
        elif station_demand < 0:
            rebalancing_amount = min(min(-station_demand, truck_capacity - truck_inventory), init_inventory)
            truck_inventory += rebalancing_amount
        return abs(abs(station_demand) - abs(rebalancing_amount)), truck_inventory, abs(rebalancing_amount)
