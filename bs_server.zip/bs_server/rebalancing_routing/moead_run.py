# -*- coding:utf-8 _*-
""" 
@author:Runqiu Hu
@license: Apache Licence 
@file: moead_run.py
@time: 2020/10/03
@contact: hurunqiu@live.com
@project: bikeshare rebalancing

* Cooperating with Dr. Matt in 2020
"""

import numpy as np
from pymoo.algorithms.moead import MOEAD
from pymoo.algorithms.nsga2 import NSGA2
from pymoo.algorithms.nsga3 import NSGA3
from bs_server.confreader import read_config as cfg
from pymoo.factory import get_sampling, get_crossover, get_mutation, get_termination
from pymoo.factory import get_visualization, get_reference_directions
from pymoo.optimize import minimize
from multiprocessing.pool import ThreadPool
import pandas as pd


from bs_server.data import station_info
from bs_server.rebalancing_preprocessing.routedistributionrepair import RouteDistributionRepair
from bs_server.rebalancing_routing.VRPProblem import BSRebalancing
from bs_server.result_evaluation.evaluate import evaluate

# client = Client()
# the number of threads to be used
n_threads = 8

# initialize the pool
pool = ThreadPool(n_threads)

def moead_run():
    problem = BSRebalancing(parallelization = ('starmap', pool.starmap))
    ref_dir = get_reference_directions("das-dennis", 3, n_partitions=12)
    algorithm = MOEAD(
        ref_dir,
        pop_size=91,
        sampling=get_sampling("perm_random"),
        n_neighbors=20,
        # repair=RouteDistributionRepair(),
        crossover=get_crossover("perm_erx"),
        mutation=get_mutation("perm_inv"),
        decomposition="tchebi",
        prob_neighbor_mating=0.7,
        seed=1,
        eliminate_duplicates=True
    )

    algorithm.repair = RouteDistributionRepair(ref_dir)

    termination = get_termination("n_gen", 250)

    res = minimize(problem, algorithm, termination, seed=1, save_history=True)

    get_visualization("scatter").add(res.F).show()
    route_index = np.unique(res.X, axis=0)
    final_result = res.F
    station_list = list(station_info.keys())
    result = np.zeros(route_index.shape)
    for row in range(route_index.shape[0]):
        for col in range(route_index.shape[1]):
            result[row, col] = station_list[route_index[row, col]] if route_index[row, col] < int(cfg('station_info', 'station_count')) else -1
    print(final_result)
    return result, final_result, res.exec_time


np.set_printoptions(threshold=np.inf)
for i in range(10):
    res = moead_run()
    result = []
    for route in res[0]:
        # print(route.astype(int))
        route_eval = evaluate(route.astype(int))
        if route_eval not in result:
            result.append(route_eval)
    pd.DataFrame(result).to_csv("exp_result_iter_" + str(i) + ".csv")
    print("执行时间：" + str(res[2]))